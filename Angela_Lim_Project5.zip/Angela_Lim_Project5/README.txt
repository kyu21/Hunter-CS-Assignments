All parts of the project were completed, including the extra Credit
No bugs were encountered

To run:
make all
make run1
or
./optimal_multiplications dimensions_file.txt

To clean:
make clean
