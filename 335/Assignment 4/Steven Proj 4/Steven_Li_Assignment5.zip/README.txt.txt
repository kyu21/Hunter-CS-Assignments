Steven Li
Assignment 5

i. I comepleted all parts of the assignment

ii. I mainly hit issues of trying to figure out the priority que container and how to use it. There were many times I got seg faults or where the program ran on indefinitely. The most difficult part was trying
to figure out algorithms to make use of the way i formatted the data from part 1. Dijkstra's algorithm took a while for me to comeplete as well as i had to figure out a way to know if the point/node is checked before or not 
and how to pick one point over another.

iii. 
step 1: enter make all into terminal
step 2: enter ./CreateGraphAndTest <GRAPH_FILE> <ADJACENCY_QUERIES_FILE>
	or  enter ./FindPaths <GRAPH_FILE>	<STARTING_VERTEX>
	or 	enter ./TopologicalSort <GRAPH_FILE>
	
iv. Input files:
	AdjacencyQueries1.txt
	AdjacencyQueries2.txt
	Graph1.txt
	Graph2.txt
	Graph3.txt